# StudyBuddy

# About Study Buddy
We wanted to create a project that can improve students life and help them save alot of time. To complete that goal we created an application that create both mindmaps and flashcards.


# Installation
1. You will need to install the code from the code section in the repository.
2. You will then need to run the code in a compillier.

# Usage
The usage of this application is helping students and others doing similiar activities to create flashcards and mindmap with alot of freedom and high amount of creativity.

This project can be used for Memorizing and Assoiciation

